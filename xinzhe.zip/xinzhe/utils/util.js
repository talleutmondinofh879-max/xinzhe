const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return `${[year, month, day].map(formatNumber).join('/')} ${[hour, minute, second].map(formatNumber).join(':')}`
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}
const showLoading = (tips = '加载中...') => {
  wx.showNavigationBarLoading()
  wx.showLoading({
    title: tips,
  })
}
 
const hideLoading = () => {
  wx.hideLoading()
  wx.hideNavigationBarLoading()
}
 
const hideLoadingWithErrorTips = (err = '加载失败...') => {
  hideLoading()
  wx.showToast({
    title: err,
    icon: 'error',
    duration: 2000
  })
}
module.exports = {
  formatTime,
  tiao,
  show,
  jump,
  launch,
  title,
  tel,
  dateFormat,
  showLoading: showLoading,
  hideLoading: hideLoading,
  hideLoadingWithErrorTips: hideLoadingWithErrorTips,
}
function dateFormat(timestamp) {
  var dateObj = new Date(timestamp);
  var year = dateObj.getFullYear();
  var month = dateObj.getMonth() + 1;
  var day = dateObj.getDate();
  var hour = dateObj.getHours();
  var minute = dateObj.getMinutes();
  var second = dateObj.getSeconds();
  return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
}
function title(title){
  wx.setNavigationBarTitle({
    title:title
  })
}
function tel(hm){
  wx.makePhoneCall({
    phoneNumber: hm, 
    success: function () {
    },
  })
}
function tiao(url){
  wx.navigateTo({
    url: url,
  })
}
function jump(url){
  wx.redirectTo({
    url: url,
  })
}
function launch(url){
  wx.reLaunch({
    url: url,
  })
}
function show(what){
  wx.showToast({
    title: what,
    icon: "none",
  });
}


