var util = require('../../utils/util.js');
var app = getApp()
Page({
  data:{
    currentPage:1,
    pageSize:6,
    list:[],
    uhide:0,
    index:'0',
    indexsex:0,
    indexstatus:0,
    sexarr:[
      {id:'',name:'ALL'},
      {id:'男',name:'男'},
      {id:'女',name:'女'},
    ],
    statusarr:[
      {id:'',name:'ALL'},
      {id:'3',name:'已全部还款'},
      {id:'2',name:'已部分还款'},
      {id:'1',name:'一分未还'},
    ], 
    indexinfo_user:0,     
    indexinfo_qudao:0,  
  
    panduan:'panduan0',
    isLoading: true,
    checkedIds:[], 
    ss:0,
    k_ss:'isPageHide',
    checkedAll:false   
  },
  ss(e){
    let that=this
    if(that.data.ss==0){
      that.setData({
        ss:1,
        k_ss:'isPageShow'
      })
    }else{
      that.setData({
        ss:0,
        k_ss:'isPageHide'
      })      
    }
  },

  handleDateChange2: function (event) {
    const selectedDate = event.detail.value;
    this.setData({
      jzr: selectedDate
    });
    //console.log(this.data.jzr)
  },
  selsex(e){
    this.setData({
      indexsex: e.detail.value,
      sex:this.data.sexarr[e.detail.value].id
    })
  },  
  selstatus(e){
    this.setData({
      indexstatus: e.detail.value,
      status:this.data.statusarr[e.detail.value].id
    })
  },  

  seltype(e){
    this.setData({
      indextype: e.detail.value,
      type:this.data.typearr[e.detail.value].id
    })
  },


  selinfo_user(e){
    this.setData({
      indexinfo_user: e.detail.value,
      ss_user:this.data.info_user[e.detail.value].id
    })
  },    

  onLoad:function(options){
    //console.log(app.globalData.sys)
    let that=this

    if(options.type){
      that.setData({
        so:'yes',
        type:this.data.typearr[options.type].id,
        indextype:options.type
      })
    }    
    
    if(options.name){
      that.setData({
        so:'yes',
        name:options.name,
      })
    }
    that.setData({
      geng:app.globalData.apiUrl,
      typeindex:app.globalData.typeindex,
      iftindex:app.globalData.iftindex,
      sex:'',
      sys:app.globalData.sys,
    })

    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=isin&c=kehu_wen&m=kehu_xuhklist',
      data: {
        currentPage: that.data.currentPage,
        pageSize: that.data.pageSize,
        user_id:app.globalData.idindex,
        user_type:app.globalData.typeindex, 
        user_ift:app.globalData.iftindex,
        so:that.data.so,
        jzr:that.data.jzr,
        status:that.data.status,
        type:that.data.type?that.data.type:'',

        name:that.data.name?that.data.name:'',
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        //console.log(res)
        // 处理返回数据
        if (res.data.success) {
          var l = res.data.data.length;
          var newData = l ? (that.data.list.concat(res.data.data)) : [];
          // 更新数据
          that.setData({
            list: newData,
            info_user:res.data.info_user,
            info_qudao:res.data.info_qudao
                }) 
        } 
      }
    })
  },

  det:function(e){
    let id=e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/kehudet/kehudet?id='+id,
    })
  },
  dian:function(e){
    let that=this
    that.setData({
      so:"yes",
      name:e.detail.value.name,
      tel:e.detail.value.tel,
      age:e.detail.value.age
    })
    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=isin&c=kehu_wen&m=kehu_xuhklist',
      data: {
        currentPage: 1,
        pageSize: that.data.pageSize,
        user_id:app.globalData.idindex,
        user_type:app.globalData.typeindex, 
        user_ift:app.globalData.iftindex,
        name:e.detail.value.name,
        tel:e.detail.value.tel,
        age:e.detail.value.age,
        jzr:that.data.jzr,
        status:that.data.status?that.data.status:'',
        sex:that.data.sex?that.data.sex:'',
        add_time:that.data.add_time?that.data.add_time:'',
        type:that.data.type?that.data.type:'',
        ss_user:that.data.ss_user?that.data.ss_user:'',
        so:"yes",
      },
      method: 'POST',
      header: {'content-type': 'application/x-www-form-urlencoded'},
      success: function (res) {
        //console.log(res)
        //return false;
        if (res.data.success) {
          var l = res.data.data.length;
          var newData = l ? (res.data.data) : [];
          // 更新数据
          that.setData({
            list: newData,
            isLoading: true,
            currentPage:1,
            k_ss:'isPageHide'
          })
          if(that.data.ss==0){
            that.setData({
              ss:1,
              k_ss:'isPageShow'
            })
          }else{
            that.setData({
              ss:0,
              k_ss:'isPageHide'
            })      
          }
        } 
      }
    })
  },
  bindPickerChange(e){
    this.setData({
      index: e.detail.value,
      sex:this.data.sexarr[e.detail.value].id
    })
  },
  fpChange(e){
    this.setData({
      index: e.detail.value,
      user:this.data.info_user[e.detail.value].id
    })
  },  
  onPageScroll: function(e) {
    // 滚动到底部，触发onReachBottom事件
    if(e.scrollHeight - e.scrollTop === e.clientHeight) {
      if(!this.data.loading) {
        this.setData({
          loading: true
        })
        // 加载下一页数据
        this.getList();
      }
    }
  },
  onReachBottom: function () {
    let that=this
    if (that.data.isLoading) {
      this.getList();
    }
  },
  getList: function () {
    var that = this;
    if (!that.data.isLoading) {
      return;
    }
    wx.showLoading({
      title: '正在加载中...',
    })
    var currentPage = that.data.currentPage + 1;
    var pageSize = that.data.pageSize;
    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=isin&c=kehu_wen&m=kehu_xuhklist',
      data: {
        currentPage: currentPage,
        pageSize: pageSize,
        user_id:app.globalData.idindex,
        user_type:app.globalData.typeindex, 
        user_ift:app.globalData.iftindex,
        name:that.data.name?that.data.name:'',
        tel:that.data.tel?that.data.tel:'',
        jzr:that.data.jzr,
        age:that.data.age?that.data.age:'',
        sex:that.data.sex?that.data.sex:'',
        status:that.data.status?that.data.status:'',
        qudao:that.data.qudao?that.data.qudao:'',                
        add_time:that.data.add_time?that.data.add_time:'',
        type:that.data.type?that.data.type:'',
        ss_user:that.data.ss_user?that.data.ss_user:'',
        so:that.data.so,
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        //console.log(res)
        wx.hideLoading();
        // 处理返回数据
        if(res.data.success) {
          var l = res.data.data.length;
          if (l === 0) {
            that.setData({
              isLoading: false
            })
            return;
          }
          var newData = that.data.list.concat(res.data.data);
          // 更新数据
          that.setData({
            list: newData,
            currentPage: currentPage
          })
        }
      }
    })
  },
  dd(e){
    let id=e.currentTarget.dataset.id
    util.tiao('../../pages/kehuadd/kehuadd?id='+id);
  },
  add(e){
    let id=e.currentTarget.dataset.id
    wx.redirectTo({
      url: '/pages/kehu_zxadd/kehu_zxadd',
    })
  },
  tg: function (event) { 
    var that = this;
    var toggleBtnVal = that.data.uhide;
    var itemId = event.currentTarget.id; 
    if (toggleBtnVal == itemId) {
      that.setData({
        uhide: 0
      })
    } else {
      that.setData({
        uhide: itemId
      })
    } 
  },


    showRule2: function () {
      let that=this
        that.setData({
          isRuleTrue2: true
        })
    },

    hideRule2: function () {
      this.setData({
        isRuleTrue2: false
      })
    },  
    showRule3: function () {
      let that=this
        that.setData({
          isRuleTrue3: true
        })
    },
    hideRule3: function () {
      let that=this
      if(that.data.ss==0){
        that.setData({
          ss:1,
          k_ss:'isPageShow'
        })
      }else{
        that.setData({
          ss:0,
          k_ss:'isPageHide'
        })      
      }
      this.setData({
        isRuleTrue2: false,
      })
    },  

})
