// pages/addUser/addUser.js
var util = require('../../utils/util.js');
var app = getApp()
Page({
    /**
     * 页面的初始数据
     */
    data: {
      index:0,
      disable:false,
      type:['用户'],
      ift:['是','不是'],
      status:['在职','离职'],
      indextype:0,
      indexstatus:0,
      indexift:0
    },
    seltype(e){
      this.setData({
        indextype:e.detail.value
      })
    },
    selift(e){
      this.setData({
        indexift:e.detail.value
      })
    },
    selstatus(e){
      this.setData({
        indexstatus:e.detail.value
      })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
      let that = this;
      that.setData({
        typeindex:app.globalData.typeindex
      })
      if(options.id){
        wx.request({
          url: app.globalData.apiUrl+'admin.php?action=isin&c=user&m=useradd', 
          method:'GET',
          data:{
            id:options.id,
          },
          header:{
            'content-type': 'application/x-www-form-urlencoded'
          },
          success:function(res){
            that.setData({
              data:res.data,
              indexstatus:res.data.status
            })
          }
        })
      }
    },

    submitFn: function (e) {
      let that = this;
      if(!e.detail.value.id){
        if (e.detail.value.username == "") {
          util.show('用户名不能为空');
          return false;
        }
        if (e.detail.value.password == "") {
          util.show('密码不能为空');
          return false;
        }
      }
      wx.request({
        url: app.globalData.apiUrl+'admin.php?action=isin&c=user&m=useradd',
        method:'POST',
        data:{
          username:e.detail.value.username,
          password:e.detail.value.password,
          type:e.detail.value.type,
          ift:e.detail.value.ift,
          id:e.detail.value.id,
          status:that.data.indexstatus,
          submit:1
        },
        header:{'content-type': 'application/x-www-form-urlencoded'},
        success:function(res){
          if(res.data.result==0){
            util.show("没有权限");
            return false;
          }else if(res.data.result==1){
            //增加成功
            that.setData({
              disable:true
            })
            util.jump("../../pages/userlist/userlist")
          }else if(res.data.result==2){
            //修改成功
            wx.showModal({
              title: '提示',
              content: '修改成功',
              showCancel: false,
              confirmText: '确定',
              success: function (res) {
                  if (res.confirm) {
                    wx.navigateBack({
                      delta: 2
                    })
                  }
              }
            })

            //util.jump("../../pages/useradd/useradd?id="+e.detail.value)
          }else if(res.data.result==3){
            util.show("存在的用户名");
            return false;
          }
        },
      })

      
    },


})