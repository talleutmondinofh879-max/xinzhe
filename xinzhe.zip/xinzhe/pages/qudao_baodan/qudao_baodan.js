var util = require('../../utils/util.js');
var app = getApp()
Page({
  data: {
    list: [{}
    ], 
    ifxian:false,
    sex66:[{id:'男',value:'男',checked: 'true'},{id:'女',value:'女'}],
    disable:false,
    sexarr:['男','女'],
    indexsex:0,
    indexinfo_qudao:0,  
    sex:'男',
    panduan:'panduan0',
    imgList: [],
    item: "",
  },
  checkboxChange(e) {
    //console.log('checkboxChange e:', e);
    let string = "riderCommentList[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.riderCommentList[e.target.dataset.index].selected
    })
    let detailValue = this.data.riderCommentList.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue)
    this.setData({detailValue:detailValue})
  },
  checkboxChange1(e) {
    //console.log('checkboxChange e:', e);
    let string = "yxxm[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.yxxm[e.target.dataset.index].selected
    })
    let detailValue1 = this.data.yxxm.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue1)
    this.setData({detailValue1:detailValue1})
  },  
  checkboxChange_qy(e) {
    //console.log('checkboxChange e:', e);
    let string = "riderCommentList_qy[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.riderCommentList_qy[e.target.dataset.index].selected
    })
    let detailValue_qy = this.data.riderCommentList_qy.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue_qy)
    this.setData({detailValue_qy:detailValue_qy})
  },
  checkboxChange1_qy(e) {
    //console.log('checkboxChange e:', e);
    let string = "yxxm_qy[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.yxxm_qy[e.target.dataset.index].selected
    })
    let detailValue1_qy = this.data.yxxm_qy.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue1_qy)
    this.setData({detailValue1_qy:detailValue1_qy})
  },    
  myTouchStart(){
    let that=this
    that.setData({
      ifxian:true
    })
  },
  selsex(e){
    this.setData({
      indexsex: e.detail.value,
      sex:this.data.sexarr[e.detail.value]
    })
  },
  
  selinfo_qudao(e){
    this.setData({
      indexinfo_qudao: e.detail.value,
      qudao:this.data.info_qudao[e.detail.value].id
    })
  },      
  selif_qd(e){
    this.setData({
      indexif_qd:e.detail.value,
      if_qd:this.data.if_qdarr[e.detail.value],
      panduan:e.detail.value==1 ? 'panduan1':'panduan0'
    })
  },      
  onLoad(options) {
    let that = this;
    that.setData({
      user_id:app.globalData.idindex
    })
    if(options.id){
 
    }else{

    }
  },

  radioChange: function (e) {
    const sex = this.data.sex
    for (let i = 0, len = sex.length; i < len; ++i) {
      sex[i].checked = sex[i].id == e.detail.value
    }
    this.setData({
      sex
    })
    console.log(this.data.sex);
  },
  dian:function(e){
    let that=this
    if (e.detail.value.name == "") {
      util.show('姓名不能为空');
      return false;
    }
    if (e.detail.value.tel == "") {
      util.show('电话不能为空');
      return false;
    }
    if (!(/^1[3456789]\d{9}$/.test(e.detail.value.tel))) {
      util.show('电话号码格式不正确');
      return false;
    }  
    if (e.detail.value.czj == "") {
      util.show('车总价不能为空');
      return false;
    }
    if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.czj))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.czj<=0){
      util.show("车总价不能小于0！")
      return false
    }
    if (e.detail.value.sfk == "") {
      util.show('首付款不能为空');
      return false;
    }
    if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.sfk))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.sfk<=0){
      util.show("首付款不能小于0！")
      return false
    }
    if(Number(e.detail.value.sfk) >= Number(e.detail.value.czj)){
      util.show("首付款不能大于车总价！")
      return false
    }
    if (e.detail.value.qishu == "") {
      util.show('期数不能为空');
      return false;
    }
    if(!(/(^[0-9]*$)/.test(e.detail.value.qishu))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.qishu<=0){
      util.show("期数不能小于0！")
      return false
    }
    if (e.detail.value.yxll == "") {
      util.show('月息利率不能为空');
      return false;
    }
    if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.yxll))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.yxll<=0){
      util.show("月息利率不能小于0！")
      return false
    }
    if (e.detail.value.bzj != "") {
      if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.bzj))){
        util.show("不要捣乱~！")
        return false
      }    
      if(e.detail.value.bzj<=0){
        util.show("保证金不能小于0！")
        return false
      }
    }
    that.setData({
      disable:true
    })


    wx.request({
      url: app.globalData.apiUrl+'ym666.php?do=qudao_baodan', 
      method:'POST',
      data:{
        user_id:app.globalData.idindex,
        name:e.detail.value.name,
        tel:e.detail.value.tel,
        czj:e.detail.value.czj,
        sfk:e.detail.value.sfk,
        qishu:e.detail.value.qishu,
        yxll:e.detail.value.yxll,
        bzj:e.detail.value.bzj,
      },
      header:{
        "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
      },
      success:function(res){
        if(res.data.code==200){
            // 遍历图片数组，逐个上传
            that.data.imgList.forEach((tempFilePath, index) => {
              wx.uploadFile({
                url: app.globalData.apiUrl+'ym666.php?do=qudao_baodan_upload', 
                filePath: that.data.imgList[index].tempFilePath,
                name: 'file', // 文件对应的 key，开发者在服务端可以通过这个 key 获取文件的二进制内容
                //header: {'Content-Type': 'multipart/form-data'},
                formData: {
                  'baodan_id': res.data.baodan_id,
                  'user_id':app.globalData.user_id           
                }, // HTTP 请求中其他额外的 form data
                success (res){
                  //const data = JSON.parse(res.data)
                  // do something
                  
                  //console.log(_this.data.kefuma)
                }
              })
            });
            wx.showModal({
              title: '提示',
              content: '成功',
              showCancel: false,
              confirmText: '确定',
              success: function (res) {
                  if (res.confirm) {
                    wx.reLaunch({
                      url: '/pages/index/index',
                    })
                  }
              }
            })
        }
      }
    })

  },

   
  chooseSource: function () {
    wx.chooseMedia({
      count: 10,
      mediaType: ['image'], //文件类型
      sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图,默认二者都有
      sourceType: ['album', 'camera'], //可以指定来源是相册还是相机, 默认二者都有
      success: (res) => {
        const _this = this;
        // 返回选定照片的本地文件路径列表,tempFilePaths可以作为img标签的scr属性显示图片
        const imgList = res.tempFiles
        let tempFilePathsImg = _this.data.imgList
        // 获取当前已上传的图片的数组
        const tempFilePathsImgs = tempFilePathsImg.concat(imgList)
        //把新增图片添加到当前数组
        _this.setData({
          imgList: tempFilePathsImgs
        })
        //console.log(_this.data.imgList)

      },
    })

  },
  //删除图片
  deleteImg: function (e) {
    const _this = this;
    const imgList = _this.data.imgList;
    const index = e.currentTarget.dataset.index; //获取当前点击图片下标
    imgList.splice(index, 1)
    _this.setData({
      imgList
    })
  },

onDepartmentChange(event)  {     // event.detail 为当前输入的值
    var  id  =  event.target.dataset.id //当前组件的id
    var name = event.target.dataset.name
    var  index  =  "list["  +  id  +  "]."  +  name;    
    this.setData({        
      [index]: event.detail.value,
    })  

    console.log(this.data.list)
  },
addDep(e) {
    var newDep = {};
    if(!this.data.list){
      this.setData({
        list:[]
      })
    }    
    var newList = this.data.list;
    newList.push(newDep);
    this.setData({
      list: newList
    })
  },
  handleDateChange: function (event) {
    const selectedDate = event.detail.value;
    this.setData({
      birth: selectedDate
    });
  },
  handleDateChange1: function (event) {
    const selectedDate = event.detail.value;
    this.setData({
      nest_time: selectedDate
    });
  },
  delDep() {
    var newList = this.data.list;
    newList.pop();
    this.setData({
      list: newList
    })
  },

  addcy:function(e){
    let that=this
    that.setData({
      isRuleTrue2: true
    })
  },
  showRule2: function () {
    let that=this

      that.setData({
        isRuleTrue2: true
      })

  },

  hideRule2: function () {
    this.setData({
      isRuleTrue2: false
    })
  },  

})