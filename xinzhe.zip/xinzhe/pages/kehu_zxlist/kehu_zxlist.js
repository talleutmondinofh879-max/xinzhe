var util = require('../../utils/util.js');
var app = getApp()
Page({
  data:{
    currentPage:1,
    pageSize:6,
    list:[],
    uhide:0,
    index:'0',
      
    isLoading: true,
    checkedIds:[], 
    ss:0,
    k_ss:'isPageHide',
    checkedAll:false   
  },
  ss(e){
    let that=this
    if(that.data.ss==0){
      that.setData({
        ss:1,
        k_ss:'isPageShow'
      })
    }else{
      that.setData({
        ss:0,
        k_ss:'isPageHide'
      })      
    }
  },


  checkboxChange(e) {
    //console.log('checkboxChange e:', e);
    let string = "riderCommentList[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.riderCommentList[e.target.dataset.index].selected
    })
    let detailValue = this.data.riderCommentList.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue)
    this.setData({detailValue:detailValue})
  },
  checkboxChange1(e) {
    //console.log('checkboxChange e:', e);
    let string = "yxxm[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.yxxm[e.target.dataset.index].selected
    })
    let detailValue1 = this.data.yxxm.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue1)
    this.setData({detailValue1:detailValue1})
  },  
  checkboxChange_qy(e) {
    //console.log('checkboxChange e:', e);
    let string = "riderCommentList_qy[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.riderCommentList_qy[e.target.dataset.index].selected
    })
    let detailValue_qy = this.data.riderCommentList_qy.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue_qy)
    this.setData({detailValue_qy:detailValue_qy})
  },
  checkboxChange1_qy(e) {
    //console.log('checkboxChange e:', e);
    let string = "yxxm_qy[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.yxxm_qy[e.target.dataset.index].selected
    })
    let detailValue1_qy = this.data.yxxm_qy.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue1_qy)
    this.setData({detailValue1_qy:detailValue1_qy})
  },   


  handleDateChange1: function (event) {
    const selectedDate = event.detail.value;
    this.setData({
      nest_time: selectedDate
    });
  },
  handleDateChange2: function (event) {
    const selectedDate = event.detail.value;
    this.setData({
      add_time: selectedDate
    });
  },
  onLoad:function(options){
    //console.log(app.globalData.sys)
    let that=this

    if(options.type){
      that.setData({
        so:'yes',
        type:this.data.typearr[options.type].id,
        indextype:options.type
      })
    }   
  

    if(options.name){
      that.setData({
        so:'yes',
        name:options.name,
      })
    }    
    that.setData({
      geng:app.globalData.apiUrl,
      typeindex:app.globalData.typeindex,
      iftindex:app.globalData.iftindex,
      sys:app.globalData.sys,  
    })

    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=isin&c=kehu_zx&m=kehu_zxlist',
      data: {
        currentPage: that.data.currentPage,
        pageSize: that.data.pageSize,
        user_id:app.globalData.idindex,
        user_type:app.globalData.typeindex, 
        user_ift:app.globalData.iftindex,
        so:that.data.so,

      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        //console.log(res)
        // 处理返回数据
        if (res.data.success) {
          var l = res.data.data.length;
          var newData = l ? (that.data.list.concat(res.data.data)) : [];
          // 更新数据
          that.setData({
            list: newData,
            info_user:res.data.info_user
                })
        } 
      }
    })
  },
  checkboxChange666(e) { // 复选框change事件
    let id = e.detail.value[0];
    let checkedIds = this.data.checkedIds;
    if (id !==undefined && id !=='') { // 判断是否选中
      checkedIds.push(id);
    }else { // 过滤出选中的复选框
      checkedIds = checkedIds.filter(item=>String(item)!==String(e.currentTarget.dataset.id));
    }
    if (checkedIds.length == this.data.list.length) { // 调整全选按钮状态
      this.setData({
        checkedIds:checkedIds,
        checkedAll:true
      })
    }else {
      this.setData({
        checkedIds:checkedIds,
        checkedAll:false
      })
    }
    //console.log(this.data.checkedIds);
  },
  selectAll(e){ // 全选框
    if (e.detail.value[0] ==="all") {
      //console.log("全部选中");
      this.setData({
        checkedIds:this.data.list.map(item=>item.id),
        list:this.data.list.map(item=>{item.checked = true;return item;})
      })
    }else { // 直接清空列表
      //console.log("清空");
      this.setData({
        checkedIds:[],
        list:this.data.list.map(item=>{item.checked = false;return item;})
      });
    }
    //console.log(this.data.checkedIds);
  },
  add_fp:function(e){
    let that=this
    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=mod&m=kehu_zx&f=kehu_zxfp',
      data: {
        user:that.data.user,
        kehu:JSON.stringify(that.data.checkedIds),
      },
      method: 'POST',
      dataType:"json",
      header: {
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
      },
      success:function(res){
        if(res.data.ok=="yes"){
          that.setData({
            disable:true,
            isRuleTrue2: false
          })
          wx.showModal({
            title: '提示',
            content: '分配成功',
            showCancel: false,
            confirmText: '确定',
            success: function (res) {
                if (res.confirm) {
                  wx.redirectTo({
                    url: '/pages/kehu_zxlist/kehu_zxlist',
                  })
                }
            }
          })
        }
      }
    })    
  },
  za:function(e){
    let that=this
    let l=that.data.checkedIds.length
    if(l==0){
      util.show("没有选中选");
      return false;
    }
    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=mod&m=kehu_zx&f=kehu_zxza',
      data: {
        id:JSON.stringify(that.data.checkedIds),
      },
      method: 'POST',
      dataType:"json",
      header: {
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
      },
      success:function(res){
        wx.showModal({
          title: '提示',
          content: res.data.mess,
          showCancel: false,
          confirmText: '确定',
          success: function (res) {
              if (res.confirm) {
                wx.redirectTo({
                  url: '/pages/kehu_zxlist/kehu_zxlist',
                })
              }
          }
        })
        //util.show(res.data.mess);
      }
    })
  },  
  yx:function(e){
    let that=this
    let l=that.data.checkedIds.length
    if(l==0){
      util.show("没有选中选");
      return false;
    }
    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=mod&m=kehu_zx&f=kehu_zxyx',
      data: {
        id:JSON.stringify(that.data.checkedIds),
      },
      method: 'POST',
      dataType:"json",
      header: {
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
      },
      success:function(res){
        wx.showToast({
          title: res.data.mess, //提示的内容
          duration: 2000, //持续的时间
          icon: 'scccess', //图标
          mask: true //显示透明蒙层 防止触摸穿透
        })
      }
    })
  },    
  del:function(e){
    let that=this
    let l=that.data.checkedIds.length
    if(l==0){
      util.show("没有选中选");
      return false;
    }
    wx.showModal({
      title: '提示',
      content: '确定删除？',
      success (res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.apiUrl+'admin.php?action=mod&m=kehu_zx&f=kehu_zxdel',
            data: {
              id:JSON.stringify(that.data.checkedIds),
            },
            method: 'POST',
            dataType:"json",
            header: {
              "Accept": "application/json, text/javascript, */*; q=0.01",
              "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
            },
            success:function(res){
              wx.redirectTo({
                url: '/pages/kehu_zxlist/kehu_zxlist',
              })
            }
          })
        } else if (res.cancel) {
          
        }
      }
    })
  },      
  fp:function(e){
    let that=this
    let l=that.data.checkedIds.length
    if(l==0){
      util.show("没有选中选");
      return false;
    }
    that.setData({
      isRuleTrue2: true
    })
    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=isin&c=kehu_zx&m=kehu_zxfp',
      data: {
        id:JSON.stringify(that.data.checkedIds),
      },
      method: 'POST',
      dataType:"json",
      header: {
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
      },
      success:function(res){
        that.setData({
          data:res.data,
          info_user:res.data.info_user,
          user:res.data.info_user[that.data.index].id
        })
      }
    })
    
  },
  det:function(e){
    let id=e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/kehudet/kehudet?id='+id,
    })
  },
  dian:function(e){
    let that=this
    that.setData({
      so:"yes",
      name:e.detail.value.name,
      tel:e.detail.value.tel,
      age:e.detail.value.age
    })
    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=isin&c=kehu_zx&m=kehu_zxlist',
      data: {
        currentPage: 1,
        pageSize: that.data.pageSize,
        user_id:app.globalData.idindex,
        user_type:app.globalData.typeindex, 
        user_ift:app.globalData.iftindex,
        name:e.detail.value.name,
        tel:e.detail.value.tel,
        age:e.detail.value.age,
        sex:that.data.sex?that.data.sex:'',
        dengji:that.data.dengji?that.data.dengji:'',
        nest_time:that.data.nest_time?that.data.nest_time:'',
        laiyuan:that.data.laiyuan?that.data.laiyuan:'',
        if_qd:that.data.if_qd?that.data.if_qd:'',
        if_za:that.data.if_za?that.data.if_za:'',
        add_time:that.data.add_time?that.data.add_time:'',
        type:that.data.type?that.data.type:'',
        sai_time:that.data.sai_time?that.data.sai_time:'',
        ss_user:that.data.ss_user?that.data.ss_user:'',
        yx_status:that.data.yx_status?that.data.yx_status:'',
        fp_status:that.data.fp_status?that.data.fp_status:'',
        yxgj:JSON.stringify(that.data.detailValue),//多选，意向国家
        yxxm:JSON.stringify(that.data.detailValue1),//多选，意向项目
        qygj:JSON.stringify(that.data.detailValue_qy),//多选，签约国家
        qyxm:JSON.stringify(that.data.detailValue1_qy),//多选，签约项目        
        so:"yes",
      },
      method: 'POST',
      header: {'content-type': 'application/x-www-form-urlencoded'},
      success: function (res) {
        //console.log(res)
        if (res.data.success) {
          var l = res.data.data.length;
          var newData = l ? (res.data.data) : [];
          // 更新数据
          that.setData({
            list: newData,
            isLoading: true,
            currentPage:1,
            k_ss:'isPageHide'
          })
          if(that.data.ss==0){
            that.setData({
              ss:1,
              k_ss:'isPageShow'
            })
          }else{
            that.setData({
              ss:0,
              k_ss:'isPageHide'
            })      
          }
        } 
      }
    })
  },
  bindPickerChange(e){
    this.setData({
      index: e.detail.value,
      sex:this.data.sexarr[e.detail.value].id
    })
  },
  fpChange(e){
    this.setData({
      index: e.detail.value,
      user:this.data.info_user[e.detail.value].id
    })
  },  
  onPageScroll: function(e) {
    // 滚动到底部，触发onReachBottom事件
    if(e.scrollHeight - e.scrollTop === e.clientHeight) {
      if(!this.data.loading) {
        this.setData({
          loading: true
        })
        // 加载下一页数据
        this.getList();
      }
    }
  },
  onReachBottom: function () {
    let that=this
    if (that.data.isLoading) {
      this.getList();
    }
  },
  getList: function () {
    var that = this;
    if (!that.data.isLoading) {
      return;
    }
    wx.showLoading({
      title: '正在加载中...',
    })
    var currentPage = that.data.currentPage + 1;
    var pageSize = that.data.pageSize;
    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=isin&c=kehu_zx&m=kehu_zxlist',
      data: {
        currentPage: currentPage,
        pageSize: pageSize,
        user_id:app.globalData.idindex,
        user_type:app.globalData.typeindex, 
        user_ift:app.globalData.iftindex,
        name:that.data.name?that.data.name:'',
        tel:that.data.tel?that.data.tel:'',
        age:that.data.age?that.data.age:'',
        sex:that.data.sex?that.data.sex:'',
        nest_time:that.data.nest_time?that.data.nest_time:'',
        laiyuan:that.data.laiyuan?that.data.dengji:'',
        add_time:that.data.add_time?that.data.add_time:'',
        type:that.data.type?that.data.type:'',
        sai_time:that.data.sai_time?that.data.sai_time:'',
        ss_user:that.data.ss_user?that.data.ss_user:'',
        so:that.data.so,
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        //console.log(res)
        wx.hideLoading();
        // 处理返回数据
        if(res.data.success) {
          var l = res.data.data.length;
          if (l === 0) {
            that.setData({
              isLoading: false
            })
            return;
          }
          var newData = that.data.list.concat(res.data.data);
          // 更新数据
          that.setData({
            list: newData,
            currentPage: currentPage
          })
        }
      }
    })
  },
  dd(e){
    let id=e.currentTarget.dataset.id
    util.tiao('../../pages/kehu_zxadd/kehu_zxadd?id='+id);
  },
  add(e){
    let id=e.currentTarget.dataset.id
    wx.redirectTo({
      url: '/pages/kehu_zxadd/kehu_zxadd',
    })
  },
  tg: function (event) { 
    var that = this;
    var toggleBtnVal = that.data.uhide;
    var itemId = event.currentTarget.id; 
    if (toggleBtnVal == itemId) {
      that.setData({
        uhide: 0
      })
    } else {
      that.setData({
        uhide: itemId
      })
    } 
  },
  tui:function(e){
    let id=e.currentTarget.dataset.id
    wx.showModal({
      title: '提示',
      content: '确定删除？',
      success (res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.apiUrl+'admin.php?action=mod&m=qudao&f=qudaodel',
            method:"POST",
            header: {
              'content-type': 'application/x-www-form-urlencoded'
            },
            data: {
              id: id
            },
            success: function (res) {
              util.show("删除成功")
              wx.redirectTo({
                url: '../../pages/qudaolist/qudaolist',
              })
            }
          })
        } else if (res.cancel) {
          
        }
      }
    })
  },

    showRule2: function () {
      let that=this
        that.setData({
          isRuleTrue2: true
        })
    },

    hideRule2: function () {
      this.setData({
        isRuleTrue2: false
      })
    },  
    showRule3: function () {
      let that=this
        that.setData({
          isRuleTrue3: true
        })
    },
    hideRule3: function () {
      let that=this
      if(that.data.ss==0){
        that.setData({
          ss:1,
          k_ss:'isPageShow'
        })
      }else{
        that.setData({
          ss:0,
          k_ss:'isPageHide'
        })      
      }
      this.setData({
        isRuleTrue2: false,
      })
    },  

})
