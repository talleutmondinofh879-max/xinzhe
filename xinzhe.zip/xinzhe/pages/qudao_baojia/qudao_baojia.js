var util = require('../../utils/util.js');
var app = getApp()
let timer = null
Page({
  data: {
    list: [{}
    ], 
    ifxian:false,
    sex66:[{id:'男',value:'男',checked: 'true'},{id:'女',value:'女'}],
    disable:false,
    sexarr:['男','女'],
    indexsex:0,
    indexinfo_qudao:0,  
    sex:'男',
    panduan:'panduan0',
    contractAmount: '',
    prepaymentAmount: '',
    finalPaymentAmount: '',
    chineseContractAmount: '',
    chinesePrepaymentAmount: '',
    chineseFinalPaymentAmount: ''
  },
  onInputChange: function(e) {
    clearTimeout(timer);
    timer = setTimeout(() => {
      const field = e.currentTarget.dataset.field;
      const value = e.detail.value;
      
      this.setData({
        [`formData.${field}`]: value,
        [`formData.chinese${this.capitalizeFirstLetter(field)}`]: this.numberToChinese(value)
      });
      
      // 更新逻辑...
    }, 300);

  },
  capitalizeFirstLetter: function(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  },
  numberToChinese: function(num) {
    if (!num || isNaN(num)) return '请输入有效数字';
    
    // 处理小数和整数部分
    num = Number(num);
    if (num >= Math.pow(10, 12)) return '数字过大';
    
    const integerPart = Math.floor(num);
    const decimalPart = Math.round((num - integerPart) * 100);
    
    let chineseStr = this.convertInteger(integerPart);
    
    if (decimalPart > 0) {
      chineseStr += '点' + this.convertDecimal(decimalPart);
    }
    if (decimalPart > 0) {
      const jiao = Math.floor(decimalPart / 10);
      const fen = decimalPart % 10;
      
      if (jiao > 0) {
        chineseStr += this.convertInteger(jiao) + '角';
      }
      if (fen > 0) {
        chineseStr += this.convertInteger(fen) + '分';
      }
    } else {
      chineseStr += '整';
    }
    
    return chineseStr || '零元整';    

  },

  convertInteger: function(num) {
    if (num === 0) return '零';
    
    const chineseNums = ['零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖'];
    const chineseUnits = ['', '拾', '佰', '仟', '万', '拾', '佰', '仟', '亿', '拾', '佰', '仟'];
    
    let result = '';
    let unitPos = 0;
    let needZero = false;
    
    while (num > 0) {
      const digit = num % 10;
      num = Math.floor(num / 10);
      
      if (digit === 0) {
        if (unitPos === 4 || unitPos === 8) {
          // 处理万和亿单位
          result = chineseUnits[unitPos] + result;
          needZero = false;
        } else {
          needZero = true;
        }
      } else {
        if (needZero) {
          result = chineseNums[0] + result;
          needZero = false;
        }
        
        result = chineseNums[digit] + chineseUnits[unitPos] + result;
      }
      
      unitPos++;
    }
    
    // 处理最后的零
    return result.replace(/零+$/, '').replace(/^零+/, '') || '零';
  },

  convertDecimal: function(num) {
    const chineseNums = ['零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖'];
    let result = '';
    
    // 处理两位小数
    const digit1 = Math.floor(num / 10);
    const digit2 = num % 10;
    
    if (digit1 > 0) {
      result += chineseNums[digit1];
    }
    if (digit2 > 0) {
      result += chineseNums[digit2];
    }
    
    return result;
  },
  checkboxChange(e) {
    //console.log('checkboxChange e:', e);
    let string = "riderCommentList[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.riderCommentList[e.target.dataset.index].selected
    })
    let detailValue = this.data.riderCommentList.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue)
    this.setData({detailValue:detailValue})
  },
  checkboxChange1(e) {
    //console.log('checkboxChange e:', e);
    let string = "yxxm[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.yxxm[e.target.dataset.index].selected
    })
    let detailValue1 = this.data.yxxm.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue1)
    this.setData({detailValue1:detailValue1})
  },  
  checkboxChange_qy(e) {
    //console.log('checkboxChange e:', e);
    let string = "riderCommentList_qy[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.riderCommentList_qy[e.target.dataset.index].selected
    })
    let detailValue_qy = this.data.riderCommentList_qy.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue_qy)
    this.setData({detailValue_qy:detailValue_qy})
  },
  checkboxChange1_qy(e) {
    //console.log('checkboxChange e:', e);
    let string = "yxxm_qy[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.yxxm_qy[e.target.dataset.index].selected
    })
    let detailValue1_qy = this.data.yxxm_qy.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue1_qy)
    this.setData({detailValue1_qy:detailValue1_qy})
  },    
  myTouchStart(){
    let that=this
    that.setData({
      ifxian:true
    })
  },
  selsex(e){
    this.setData({
      indexsex: e.detail.value,
      sex:this.data.sexarr[e.detail.value]
    })
  },
  
  selinfo_qudao(e){
    this.setData({
      indexinfo_qudao: e.detail.value,
      qudao:this.data.info_qudao[e.detail.value].id
    })
  },      
  selif_qd(e){
    this.setData({
      indexif_qd:e.detail.value,
      if_qd:this.data.if_qdarr[e.detail.value],
      panduan:e.detail.value==1 ? 'panduan1':'panduan0'
    })
  },      
  onLoad(options) {
    let that = this;
    that.setData({
      user_id:app.globalData.idindex
    })
    wx.request({
      url: app.globalData.apiUrl+'ym666.php?do=getsys',
      method:'POST',
      data:{

      },
      header: { 'content-type': 'application/x-www-form-urlencoded'}, 
      success: (res) => {
        //console.log(res.data)
        that.setData({txt:res.data.txt})
      },
    })
    if(options.id){
 
    }else{

    }
  },

  radioChange: function (e) {
    const sex = this.data.sex
    for (let i = 0, len = sex.length; i < len; ++i) {
      sex[i].checked = sex[i].id == e.detail.value
    }
    this.setData({
      sex
    })
    console.log(this.data.sex);
  },
  dian:function(e){
    let that=this
    if (e.detail.value.czj == "") {
      util.show('车总价不能为空');
      return false;
    }
    if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.czj))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.czj<=0){
      util.show("车总价不能小于0！")
      return false
    }
    if (e.detail.value.sfk == "") {
      util.show('首付款不能为空');
      return false;
    }
    if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.sfk))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.sfk<=0){
      util.show("首付款不能小于0！")
      return false
    }
    if(Number(e.detail.value.sfk) >= Number(e.detail.value.czj)){
      util.show("首付款不能大于车总价！")
      return false
    }
    if (e.detail.value.qishu == "") {
      util.show('期数不能为空');
      return false;
    }
    if(!(/(^[0-9]*$)/.test(e.detail.value.qishu))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.qishu<=0){
      util.show("期数不能小于0！")
      return false
    }
    if (e.detail.value.yxll == "") {
      util.show('月息利率不能为空');
      return false;
    }
    if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.yxll))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.yxll<=0){
      util.show("月息利率不能小于0！")
      return false
    }
    if (e.detail.value.bzj != "") {
      if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.bzj))){
        util.show("不要捣乱~！")
        return false
      }    
      if(e.detail.value.bzj<=0){
        util.show("保证金不能小于0！")
        return false
      }
    }
    that.setData({
      disable:true
    })


    wx.request({
      url: app.globalData.apiUrl+'ym666.php?do=qudao_baojia', 
      method:'POST',
      data:{
        user_id:app.globalData.idindex,
        czj:e.detail.value.czj,
        sfk:e.detail.value.sfk,
        qishu:e.detail.value.qishu,
        yxll:e.detail.value.yxll,
        bzj:e.detail.value.bzj,
      },
      header:{
        "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
      },
      success:function(res){
        //console.log(res)
        if(res.data.code==200){
          that.setData({
            fanyong:res.data.fanyong,
            yuehuankuan:res.data.yuehuankuan
          })
        }else{
          util.show(res.data.mess)
          return false
        }
      }
    })

  },

onDepartmentChange(event)  {     // event.detail 为当前输入的值
    var  id  =  event.target.dataset.id //当前组件的id
    var name = event.target.dataset.name
    var  index  =  "list["  +  id  +  "]."  +  name;    
    this.setData({        
      [index]: event.detail.value,
    })  

    console.log(this.data.list)
  },
addDep(e) {
    var newDep = {};
    if(!this.data.list){
      this.setData({
        list:[]
      })
    }    
    var newList = this.data.list;
    newList.push(newDep);
    this.setData({
      list: newList
    })
  },
  handleDateChange: function (event) {
    const selectedDate = event.detail.value;
    this.setData({
      birth: selectedDate
    });
  },
  handleDateChange1: function (event) {
    const selectedDate = event.detail.value;
    this.setData({
      nest_time: selectedDate
    });
  },
  delDep() {
    var newList = this.data.list;
    newList.pop();
    this.setData({
      list: newList
    })
  },

  addcy:function(e){
    let that=this
    that.setData({
      isRuleTrue2: true
    })
  },
  showRule2: function () {
    let that=this

      that.setData({
        isRuleTrue2: true
      })

  },

  hideRule2: function () {
    this.setData({
      isRuleTrue2: false
    })
  },  

})