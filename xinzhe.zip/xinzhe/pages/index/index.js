var util = require('../../utils/util.js');
var app = getApp();
Page({
  data:{
    isPage:'isPageHide',
    disable:false,
  },
  onLoad(options){
    let that=this;
    app.globalData.selected=0
    wx.login({//获取用户的openid
      success: (res) => {
        if(res.code){
          wx.request({
            url: app.globalData.apiUrl+'ym666.php?do=openid',
            data: {
              code: res.code
            },
            success:(res) => {
              //console.log(res)
              that.setData({
                openid:res.data.openid,
              })
              app.globalData.openid=res.data.openid
              wx.request({
                url: app.globalData.apiUrl+'ym666.php?do=pStatus',
                method:'POST',
                data:{
                  openid:res.data.openid
                },
                header: { 'content-type': 'application/x-www-form-urlencoded'}, 
                success:function(res){
                  if(res.data.s=="no"){
                    util.launch("../../pages/login/login");
                    return false
                  }else if(res.data.s=="yes"){
                    app.globalData.typeindex=res.data.userinfo.type
                    app.globalData.iftindex=res.data.userinfo.ift
                    app.globalData.idindex=res.data.userinfo.id
                    app.globalData.w_id=res.data.userinfo.w_id
                    app.globalData.nameindex=res.data.userinfo.username
                    that.setData({
                      isPage:'isPageShow',
                      typeindex:app.globalData.typeindex,
                      iftindex:app.globalData.iftindex,
                      idindex:app.globalData.idindex               
                    })
                    if(app.globalData.typeindex==3){//////用户
                        wx.request({
                          url: app.globalData.apiUrl+'ym666.php?do=getkehuinfo',
                          method:'POST',
                          data:{
                            user_id:app.globalData.idindex
                          },
                          header: { 'content-type': 'application/x-www-form-urlencoded'}, 
                          success: (res) => {
                            //console.log(res)
                            that.setData({kehuinfo:res.data})
                          },
                        })
                    }
                    if(app.globalData.typeindex==2){/////渠道
                      wx.request({
                        url: app.globalData.apiUrl+'ym666.php?do=getqudaoinfo',
                        method:'POST',
                        data:{
                          user_id:app.globalData.idindex
                        },
                        header: { 'content-type': 'application/x-www-form-urlencoded'}, 
                        success: (res) => {
                          //console.log(res)
                          that.setData({qudaoinfo:res.data})
                        },
                      })
                    }
                    if(app.globalData.typeindex==1){/////////市场
                      wx.request({
                        url: app.globalData.apiUrl+'ym666.php?do=getshichanginfo',
                        method:'POST',
                        data:{
                          user_id:app.globalData.idindex
                        },
                        header: { 'content-type': 'application/x-www-form-urlencoded'}, 
                        success: (res) => {
                          //console.log(res.data)
                          that.setData({shichanginfo:res.data})
                        },
                      })
                    }                    
                  }
                }
              })
            }
          })            
        }else{
          console.log('登录失败！'+res.errMsg);
        }
      },
    })
  },
  zhifu: function (e) {
    let that=this
    //console.log(app.globalData.apiUrl);
    //console.log(app.globalData.w_id)

    if(e.detail.value.hkje==''){
      util.show('请输入还款金额');
      return false;
    }

    if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.hkje))){
      util.show("不要捣乱~！")
      return false
    }       

    that.setData({
      disable:true,
      totalPrice:e.detail.value.hkje
    })
    setTimeout(() => {
      that.setData({
        disable: false
      });
    }, 2000);

    //return false

    wx.request({
        url: app.globalData.apiUrl+'ym666.php?do=pay',
        data: {
          attach:app.globalData.w_id,
          money:e.detail.value.hkje,
          openid:app.globalData.openid
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success:(res)=>{
          //console.log(res)
          //return false
          if(res.data.status=='error'){
            util.show(res.data.txt)
            return false
          }
            wx.requestPayment({
                'timeStamp': res.data.timeStamp,
                'nonceStr': res.data.nonceStr,
                'package': res.data.package,            
                'signType': 'MD5',          
                'paySign': res.data.paySign,
                'success':function(res){
                    //支付成功 
                    //util.launch('/pages/projectlist/projectlist?w=all')
                    util.launch('/pages/result/result?price='+that.data.totalPrice+'&status=1&type=1')
                    //util.launch('/pages/index/index')
                },
                'fail':function(res){
                  //util.launch('/pages/projectlist/projectlist?w=a1')
                  util.launch('/pages/result/result?price='+that.data.totalPrice+'&status=2&type=2')
                    //util.launch('/pages/index/index')
                }
            })
        },
    })
  },
  detkehu(e){
    let id=e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/kehudet/kehudet?id='+id,
    })
  },
  xiaoxi(e){
    let id=e.currentTarget.dataset.id
    if(app.globalData.typeindex==2){
      wx.redirectTo({
        url: '/pages/kehudet/kehudet?kan=yes&id='+id,
      })
    }else if(app.globalData.typeindex==3){
      wx.redirectTo({
        url: '/pages/kehu_wendet/kehu_wendet?kan=yes&id='+id,
      })
    }else if(app.globalData.typeindex==0){
      wx.redirectTo({
        url: '/pages/kehudet/kehudet?kan=yes&id='+id,
      })
    }else{}
  },
  shengri(e){
    let id=e.currentTarget.dataset.id
    if(app.globalData.typeindex==2){
      wx.redirectTo({
        url: '/pages/kehudet/kehudet?id='+id,
      })
    }else if(app.globalData.typeindex==3){
      wx.redirectTo({
        url: '/pages/kehu_wendet/kehu_wendet?id='+id,
      })
    }else if(app.globalData.typeindex==0){
      wx.redirectTo({
        url: '/pages/kehudet/kehudet?id='+id,
      })
    }else{}
  },
  shenpi(e){
    let id=e.currentTarget.dataset.id
    wx.redirectTo({
      url: '/pages/baoxiaolist/baoxiaolist?w='+id,
    })
  },

  kehu(e){
    let id=e.currentTarget.dataset.id
    let name=e.currentTarget.dataset.name
    wx.navigateTo({
      url: '/pages/kehu_zxlist/kehu_zxlist?'+name+'='+id,
    })
  },
  kehu1(e){
    let id=e.currentTarget.dataset.id
    let name=e.currentTarget.dataset.name
    wx.navigateTo({
      url: '/pages/kehulist/kehulist?'+name+'='+id,
    })
  },  
  genjin(e){
    let id=e.currentTarget.dataset.id
    let name=e.currentTarget.dataset.name
    wx.navigateTo({
      url: '/pages/genjinlist/genjinlist?'+name+'='+id,
    })
  },
  kehu_wen(e){
    let id=e.currentTarget.dataset.id
    let name=e.currentTarget.dataset.name
    wx.navigateTo({
      url: '/pages/kehu_wenlist/kehu_wenlist?'+name+'='+id,
    })
  },
  sea(e){
    if(e.detail.value.username==''){
      util.show('请输入客户姓名');
      return false;
    }
    if(app.globalData.typeindex==0){
      wx.navigateTo({
        url: '/pages/kehu_zxlist/kehu_zxlist?name='+e.detail.value.username
      })
    }else if(app.globalData.typeindex==2){
      wx.navigateTo({
        url:'/pages/kehulist/kehulist?name='+e.detail.value.username
      })
    }else{

    }
  },
  det8(e){
    let name=e.currentTarget.dataset.name
    wx.navigateTo({
      url:'/pages/kehu_zxlist/kehu_zxlist?name='+name
    })
  },
  zhuan(e){
    let id=e.currentTarget.dataset.id
    if(!id){
      util.show('参数错误');
      return false;
    }
    util.tiao('/pages/'+id+'/'+id);
  },
  zhuanwen(e){
    let id=e.currentTarget.dataset.id
    if(!id){
      util.show('参数错误');
      return false;
    }
    util.tiao('/pages/'+id+'/'+id+'?from1=wen');
  },  
  dao(e){
    let id=e.currentTarget.dataset.id
    if(!id){
      util.show('参数错误');
      return false;
    }
    util.tiao('/pages/'+id+'/'+id);
  },
  mp() {
    const phoneNumber = '15902703738';
    wx.makePhoneCall({
      phoneNumber: phoneNumber
    })
  },
  onShareAppMessage: function () {
    return {
      title: '信哲商用车',
      path: '/pages/index/index',
      imageUrl: '/img/fm.jpg'
    }
  }

})

