var util = require('../../utils/util.js');
var app = getApp()
Page({
  data:{
    currentPage:1,
    pageSize:4,
    list:[],
    uhide:0,
    isLoading: true   
  },
  onLoad:function(options){
    let that=this
    that.setData({geng:app.globalData.apiUrl})

    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=isin&c=user&m=userlist',
      data: {
        currentPage: that.data.currentPage,
        pageSize: that.data.pageSize,
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        // 处理返回数据
        if (res.data.success) {
          var l = res.data.data.length;
          var newData = l ? (that.data.list.concat(res.data.data)) : [];
          // 更新数据
          that.setData({
            list: newData      })
        } 
      }
    })
  },
  dian:function(e){
    let that=this
    let w=e.currentTarget.dataset.id
    that.setData({w:w})
    wx.request({
      url: app.globalData.apiUrl+'index.php?do=getatuiKuan',
      data: {
        currentPage: 1,
        pageSize: that.data.pageSize,
        s_id:app.globalData.softinfo.id,
        w:w
      },
      method: 'POST',
      header: {'content-type': 'application/x-www-form-urlencoded'},
      success: function (res) {
        if (res.data.success) {
          var l = res.data.data.length;
          var newData = l ? (res.data.data) : [];
          // 更新数据
          that.setData({
            list: newData,
            isLoading: true,
            currentPage:1      
          })
        } 
      }
    })
  },
  onPageScroll: function(e) {
    // 滚动到底部，触发onReachBottom事件
    if(e.scrollHeight - e.scrollTop === e.clientHeight) {
      if(!this.data.loading) {
        this.setData({
          loading: true
        })
        // 加载下一页数据
        this.getList();
      }
    }
  },
  onReachBottom: function () {
    let that=this
    if (that.data.isLoading) {
      this.getList();
    }
  },
  getList: function () {
    var that = this;
    if (!that.data.isLoading) {
      return;
    }
    wx.showLoading({
      title: '正在加载中...',
    })
    var currentPage = that.data.currentPage + 1;
    var pageSize = that.data.pageSize;
    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=isin&c=user&m=userlist',
      data: {
        currentPage: currentPage,
        pageSize: pageSize,
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        wx.hideLoading();
        // 处理返回数据
        if(res.data.success) {
          var l = res.data.data.length;
          if (l === 0) {
            that.setData({
              isLoading: false
            })
            return;
          }
          var newData = that.data.list.concat(res.data.data);
          // 更新数据
          that.setData({
            list: newData,
            currentPage: currentPage
          })
        }
      }
    })
  },
  dd(e){
    let id=e.currentTarget.dataset.id
    util.tiao('../../pages/useradd/useradd?id='+id);
  },
  tg: function (event) { 
    var that = this;
    var toggleBtnVal = that.data.uhide;
    var itemId = event.currentTarget.id; 
    if (toggleBtnVal == itemId) {
      that.setData({
        uhide: 0
      })
    } else {
      that.setData({
        uhide: itemId
      })
    } 
  },
  tui:function(e){
    let id=e.currentTarget.dataset.id
    wx.showModal({
      title: '提示',
      content: '确定删除？',
      success (res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.apiUrl+'admin.php?action=mod&m=user&f=userdel',
            data: {
              id: id
            },
            success: function (res) {
              util.show("删除成功")
              wx.redirectTo({
                url: '../../pages/userlist/userlist',
              })
            }
          })
        } else if (res.cancel) {
          
        }
      }
    })
  }
})
