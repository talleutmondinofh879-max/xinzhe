var util = require('../../utils/util.js');
var app = getApp()
Page({
  data: {
    list: [{}
    ], 
    ifxian:false,
    disable:false,
    indexinfo_qudao:0,  
    panduan:'panduan0'
  },
 
  myTouchStart(){
    let that=this
    that.setData({
      ifxian:true
    })
  },

  selinfo_qudao(e){
    this.setData({
      indexinfo_qudao: e.detail.value,
      qudao:this.data.info_qudao[e.detail.value].id
    })
  },      
  onLoad(options) {
    let that = this;
    that.setData({
      user_id:app.globalData.idindex
    })
    if(options.id){
 
    }else{

    }
  },

  dian:function(e){
    let that=this
    if (e.detail.value.irr == "") {
      util.show('IRR不能为空');
      return false;
    }
    if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.irr))){
      util.show("不要捣乱~！")
      return false
    }    
    if (e.detail.value.czj == "") {
      util.show('车总价不能为空');
      return false;
    }
    if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.czj))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.czj<=0){
      util.show("车总价不能小于0！")
      return false
    }
    if (e.detail.value.sfk == "") {
      util.show('首付款不能为空');
      return false;
    }
    if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.sfk))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.sfk<=0){
      util.show("首付款不能小于0！")
      return false
    }
    if(Number(e.detail.value.sfk) >= Number(e.detail.value.czj)){
      util.show("首付款不能大于车总价！")
      return false
    }
    if (e.detail.value.qishu == "") {
      util.show('期数不能为空');
      return false;
    }
    if(!(/(^[0-9]*$)/.test(e.detail.value.qishu))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.qishu<=0){
      util.show("期数不能小于0！")
      return false
    }
    if (e.detail.value.yxll == "") {
      util.show('月息利率不能为空');
      return false;
    }
    if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.yxll))){
      util.show("不要捣乱~！")
      return false
    }    
    if(e.detail.value.yxll<=0){
      util.show("月息利率不能小于0！")
      return false
    }
    if (e.detail.value.bzj != "") {
      if(!(/(^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$)/.test(e.detail.value.bzj))){
        util.show("不要捣乱~！")
        return false
      }    
      if(e.detail.value.bzj<=0){
        util.show("保证金不能小于0！")
        return false
      }
    }
    that.setData({
      disable:true
    })


    wx.request({
      url: app.globalData.apiUrl+'ym666.php?do=qudao_baojia1', 
      method:'POST',
      data:{
        user_id:app.globalData.idindex,
        irr:e.detail.value.irr,
        czj:e.detail.value.czj,
        sfk:e.detail.value.sfk,
        qishu:e.detail.value.qishu,
        yxll:e.detail.value.yxll,
        bzj:e.detail.value.bzj,
      },
      header:{
        "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
      },
      success:function(res){
        //console.log(res)
        if(res.data.code==200){
          that.setData({
            fanyong:res.data.fanyong,
            yuehuankuan:res.data.yuehuankuan
          })
        }else{
          util.show(res.data.mess)
          return false
        }
      }
    })

  },


  showRule2: function () {
    let that=this

      that.setData({
        isRuleTrue2: true
      })

  },

  hideRule2: function () {
    this.setData({
      isRuleTrue2: false
    })
  },  

})