// pages/login/login.js
var util = require('../../utils/util.js');
var app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
      disable:false,
      avatarUrl:'/img/mo.png',

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
      let that=this
      that.setData({username:options.username})
    },
    bindchooseavatar(e) {
      this.setData({
        avatarUrl:e.detail.avatarUrl,
      })
    },
    submitFn:function(e){//保存用户头像和昵称
      let that=this
      if(that.data.avatarUrl=='/img/mo.png'){
        util.show('请选择头像');
        return false;
      }
      if(e.detail.value.nickName==''){
        util.show('请输入昵称');
        return false;
      }
      wx.uploadFile({
        url: app.globalData.apiUrl+'ym666.php?do=uploadTx', 
        filePath: that.data.avatarUrl,
        name: 'file', // 文件对应的 key，开发者在服务端可以通过这个 key 获取文件的二进制内容
        //header: {'Content-Type': 'multipart/form-data'},
        formData: {
          'openid':app.globalData.openid,
          'nickName':e.detail.value.nickName,
          'username':this.data.username
        }, // HTTP 请求中其他额外的 form data
        success (res){
          //const data = JSON.parse(res.data)
          app.globalData.nickName=e.detail.value.nickName;
          app.globalData.avatarUrl=res.data;
          util.launch("../../pages/index/index");
        }
      })
    },
   
})