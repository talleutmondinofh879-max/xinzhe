var util = require('../../utils/util.js');
var app = getApp();
Page({
  onShow: function () {
    if (typeof this.getTabBar === "function" && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 2
      })
    }
  },
  onLoad(options){
    let that=this;
    that.setData({
      geng:app.globalData.apiUrl,
      openid:app.globalData.openid,
      typeindex:app.globalData.typeindex,
      idindex:app.globalData.idindex
    })    
    wx.request({
      url: app.globalData.apiUrl+'ym666.php?do=getMyTop',
      method:'POST',
      header:{'content-type': 'application/x-www-form-urlencoded'},
      data:{
        openid:app.globalData.openid,
      },
      success:function(res){
        that.setData({
          info:res.data
        })
      }
    })
  },
  lgout:function(e){
    let id=e.currentTarget.dataset.id
    wx.showModal({
      title: '提示',
      content: '确定退出？',
      success (res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.apiUrl+'admin.php?action=isin&c=logout',
            method:'POST',
            header:{
              'content-type': 'application/x-www-form-urlencoded'
            },
            data: {
              openid: id
            },
            success: function (res) {
              if(res.data=="yes"){
                wx.redirectTo({
                  url: '../../pages/login/login',
                })
              }
            }
          })
        } else if (res.cancel) {
          
        }
      }
    })
  },
  sea(e){
    if(e.detail.value.username==''){
      util.show('请输入搜索内容');
      return false;
    }
    util.launch('/pages/dingdan/dingdan?username='+e.detail.value.username);
  },
  dao(e){
    let id=e.currentTarget.dataset.id
    let id1=e.currentTarget.dataset.id1
    if(!id){
      util.show('参数错误');
      return false;
    }
    util.tiao('/pages/'+id+'/'+id+'?id='+id1);
  }
})

