var util = require('../../utils/util.js');
var app = getApp()
Page({
  data:{
    currentPage:1,
    pageSize:6,
    list:[],
    uhide:0,
    index:'0',
      
    isLoading: true,
    checkedIds:[], 
    ss:0,
    k_ss:'isPageHide',
    checkedAll:false   
  },
  ss(e){
    let that=this
    if(that.data.ss==0){
      that.setData({
        ss:1,
        k_ss:'isPageShow'
      })
    }else{
      that.setData({
        ss:0,
        k_ss:'isPageHide'
      })      
    }
  },

  onLoad:function(options){
    //console.log(app.globalData.sys)
    let that=this

    that.setData({
      geng:app.globalData.apiUrl,
      typeindex:app.globalData.typeindex,
      iftindex:app.globalData.iftindex,
      sys:app.globalData.sys,  
      kehu_id:options.id
    })

    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=isin&c=kehu_zx&m=kehu_zx1list',
      data: {
        currentPage: that.data.currentPage,
        pageSize: that.data.pageSize,
        user_id:app.globalData.user_id, 
        kehu_id:that.data.kehu_id,
        user_type:app.globalData.typeindex, 
        user_ift:app.globalData.iftindex,
        so:that.data.so,

      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        //console.log(res)
        // 处理返回数据
        if (res.data.success) {
          var l = res.data.data.length;
          var newData = l ? (that.data.list.concat(res.data.data)) : [];
          // 更新数据
          that.setData({
            list: newData,
            info_user:res.data.info_user
                })
        } 
      }
    })
  },
  checkboxChange666(e) { // 复选框change事件
    let id = e.detail.value[0];
    let checkedIds = this.data.checkedIds;
    if (id !==undefined && id !=='') { // 判断是否选中
      checkedIds.push(id);
    }else { // 过滤出选中的复选框
      checkedIds = checkedIds.filter(item=>String(item)!==String(e.currentTarget.dataset.id));
    }
    if (checkedIds.length == this.data.list.length) { // 调整全选按钮状态
      this.setData({
        checkedIds:checkedIds,
        checkedAll:true
      })
    }else {
      this.setData({
        checkedIds:checkedIds,
        checkedAll:false
      })
    }
    //console.log(this.data.checkedIds);
  },
  selectAll(e){ // 全选框
    if (e.detail.value[0] ==="all") {
      //console.log("全部选中");
      this.setData({
        checkedIds:this.data.list.map(item=>item.id),
        list:this.data.list.map(item=>{item.checked = true;return item;})
      })
    }else { // 直接清空列表
      //console.log("清空");
      this.setData({
        checkedIds:[],
        list:this.data.list.map(item=>{item.checked = false;return item;})
      });
    }
    //console.log(this.data.checkedIds);
  },

  det:function(e){
    let id=e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/kehudet/kehudet?id='+id,
    })
  },

  bindPickerChange(e){
    this.setData({
      index: e.detail.value,
      sex:this.data.sexarr[e.detail.value].id
    })
  },
  fpChange(e){
    this.setData({
      index: e.detail.value,
      user:this.data.info_user[e.detail.value].id
    })
  },  
  onPageScroll: function(e) {
    // 滚动到底部，触发onReachBottom事件
    if(e.scrollHeight - e.scrollTop === e.clientHeight) {
      if(!this.data.loading) {
        this.setData({
          loading: true
        })
        // 加载下一页数据
        this.getList();
      }
    }
  },
  onReachBottom: function () {
    let that=this
    if (that.data.isLoading) {
      this.getList();
    }
  },
  getList: function () {
    var that = this;
    if (!that.data.isLoading) {
      return;
    }
    wx.showLoading({
      title: '正在加载中...',
    })
    var currentPage = that.data.currentPage + 1;
    var pageSize = that.data.pageSize;
    wx.request({
      url: app.globalData.apiUrl+'admin.php?action=isin&c=kehu_zx&m=kehu_zx1list',
      data: {
        currentPage: currentPage,
        pageSize: pageSize,
        user_id:app.globalData.idindex,
        kehu_id:that.data.kehu_id,
        user_type:app.globalData.typeindex, 
        user_ift:app.globalData.iftindex,
        name:that.data.name?that.data.name:'',
        tel:that.data.tel?that.data.tel:'',
        age:that.data.age?that.data.age:'',
        sex:that.data.sex?that.data.sex:'',
        nest_time:that.data.nest_time?that.data.nest_time:'',
        add_time:that.data.add_time?that.data.add_time:'',
        type:that.data.type?that.data.type:'',
        ss_user:that.data.ss_user?that.data.ss_user:'',
        so:that.data.so,
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        //console.log(res)
        wx.hideLoading();
        // 处理返回数据
        if(res.data.success) {
          var l = res.data.data.length;
          if (l === 0) {
            that.setData({
              isLoading: false
            })
            return;
          }
          var newData = that.data.list.concat(res.data.data);
          // 更新数据
          that.setData({
            list: newData,
            currentPage: currentPage
          })
        }
      }
    })
  },
  dd(e){
    let id=e.currentTarget.dataset.id
    util.tiao('../../pages/kehu_zxadd/kehu_zxadd?id='+id);
  },
  add(e){
    let id=e.currentTarget.dataset.id
    wx.redirectTo({
      url: '/pages/kehu_zxadd/kehu_zxadd',
    })
  },
  tg: function (event) { 
    var that = this;
    var toggleBtnVal = that.data.uhide;
    var itemId = event.currentTarget.id; 
    if (toggleBtnVal == itemId) {
      that.setData({
        uhide: 0
      })
    } else {
      that.setData({
        uhide: itemId
      })
    } 
  },
    showRule2: function () {
      let that=this
        that.setData({
          isRuleTrue2: true
        })
    },

    hideRule2: function () {
      this.setData({
        isRuleTrue2: false
      })
    },  
    showRule3: function () {
      let that=this
        that.setData({
          isRuleTrue3: true
        })
    },
    hideRule3: function () {
      let that=this
      if(that.data.ss==0){
        that.setData({
          ss:1,
          k_ss:'isPageShow'
        })
      }else{
        that.setData({
          ss:0,
          k_ss:'isPageHide'
        })      
      }
      this.setData({
        isRuleTrue2: false,
      })
    },  

})
