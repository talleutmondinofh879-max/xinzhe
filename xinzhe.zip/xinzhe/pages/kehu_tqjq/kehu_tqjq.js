var util = require('../../utils/util.js');
var app = getApp()
Page({
  data: {
    list: [{}
    ], 
    ifxian:false,
    sex66:[{id:'男',value:'男',checked: 'true'},{id:'女',value:'女'}],
    disable:false,
    sexarr:['男','女'],
    indexsex:0,
    indexinfo_qudao:0,  
    sex:'男',
    panduan:'panduan0'
  },
  checkboxChange(e) {
    //console.log('checkboxChange e:', e);
    let string = "riderCommentList[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.riderCommentList[e.target.dataset.index].selected
    })
    let detailValue = this.data.riderCommentList.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue)
    this.setData({detailValue:detailValue})
  },
  checkboxChange1(e) {
    //console.log('checkboxChange e:', e);
    let string = "yxxm[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.yxxm[e.target.dataset.index].selected
    })
    let detailValue1 = this.data.yxxm.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue1)
    this.setData({detailValue1:detailValue1})
  },  
  checkboxChange_qy(e) {
    //console.log('checkboxChange e:', e);
    let string = "riderCommentList_qy[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.riderCommentList_qy[e.target.dataset.index].selected
    })
    let detailValue_qy = this.data.riderCommentList_qy.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue_qy)
    this.setData({detailValue_qy:detailValue_qy})
  },
  checkboxChange1_qy(e) {
    //console.log('checkboxChange e:', e);
    let string = "yxxm_qy[" + e.target.dataset.index + "].selected"
    this.setData({
      [string]: !this.data.yxxm_qy[e.target.dataset.index].selected
    })
    let detailValue1_qy = this.data.yxxm_qy.filter(it => it.selected).map(it => it.value)
    console.log('所有选中的值为：', detailValue1_qy)
    this.setData({detailValue1_qy:detailValue1_qy})
  },    
  myTouchStart(){
    let that=this
    that.setData({
      ifxian:true
    })
  },
  selsex(e){
    this.setData({
      indexsex: e.detail.value,
      sex:this.data.sexarr[e.detail.value]
    })
  },
  
  selinfo_qudao(e){
    this.setData({
      indexinfo_qudao: e.detail.value,
      qudao:this.data.info_qudao[e.detail.value].id
    })
  },      
  selif_qd(e){
    this.setData({
      indexif_qd:e.detail.value,
      if_qd:this.data.if_qdarr[e.detail.value],
      panduan:e.detail.value==1 ? 'panduan1':'panduan0'
    })
  },      
  onLoad(options) {
    let that = this;
    that.setData({
      user_id:app.globalData.idindex
    })
    if(options.id){
 
    }else{

    }
  },

  radioChange: function (e) {
    const sex = this.data.sex
    for (let i = 0, len = sex.length; i < len; ++i) {
      sex[i].checked = sex[i].id == e.detail.value
    }
    this.setData({
      sex
    })
    console.log(this.data.sex);
  },
  dian:function(e){
    let that=this

    that.setData({
      disable:true
    })
    wx.request({
      url: app.globalData.apiUrl+'ym666.php?do=kehu_tqjq', 
      method:'POST',
      data:{
        user_id:app.globalData.idindex,
      },
      header:{
        "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"
      },
      success:function(res){
        //console.log(res)
          that.setData({
            sum:res.data.sum,
          })

      }
    })

  },

onDepartmentChange(event)  {     // event.detail 为当前输入的值
    var  id  =  event.target.dataset.id //当前组件的id
    var name = event.target.dataset.name
    var  index  =  "list["  +  id  +  "]."  +  name;    
    this.setData({        
      [index]: event.detail.value,
    })  

    console.log(this.data.list)
  },
addDep(e) {
    var newDep = {};
    if(!this.data.list){
      this.setData({
        list:[]
      })
    }    
    var newList = this.data.list;
    newList.push(newDep);
    this.setData({
      list: newList
    })
  },
  handleDateChange: function (event) {
    const selectedDate = event.detail.value;
    this.setData({
      birth: selectedDate
    });
  },
  handleDateChange1: function (event) {
    const selectedDate = event.detail.value;
    this.setData({
      nest_time: selectedDate
    });
  },
  delDep() {
    var newList = this.data.list;
    newList.pop();
    this.setData({
      list: newList
    })
  },

  addcy:function(e){
    let that=this
    that.setData({
      isRuleTrue2: true
    })
  },
  showRule2: function () {
    let that=this

      that.setData({
        isRuleTrue2: true
      })

  },

  hideRule2: function () {
    this.setData({
      isRuleTrue2: false
    })
  },  

})