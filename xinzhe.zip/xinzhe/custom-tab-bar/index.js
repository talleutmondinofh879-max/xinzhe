const app=getApp()
Component({
  options: {
    addGlobalClass: true,
  },
  data: {
    selected: null,
    color: "#7A7E83",
    selectedColor: "#4259EA",
    list: [
      {
        "pagePath": "/pages/index/index",
        "text": "首页",
        "iconPath": "/img/a2.png",
        "selectedIconPath": "/img/a1.png"
      },



      {
        "pagePath": "/pages/my/my",
        "text": "我的",
        "iconPath": "/img/e2.png",
        "selectedIconPath": "/img/e1.png"
      }
  ]
  },
  ready:function(){
    this.setData({
      selected:app.globalData.selected
    })
  },
  attached() {
  },
  methods: {
    switchTab(e) {
      const data = e.currentTarget.dataset
      const url = data.path
      app.globalData.selected=data.index
      wx.reLaunch({url})
    }
  }
})