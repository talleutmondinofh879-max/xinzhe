// app.js
App({
  onLaunch(options) {
    let that=this
    wx.hideTabBar()
  },
  globalData: {
    nickName:'',
    sys:[],
    avatarUrl:'/img/mo.png',
    openid:'',
    typeindex:'',
    iftindex:'',
    idindex:'',
    w_id:'',
    nameindex:'',
    selected:0,
    apiUrl:'https://test.hbbdf.cn/xinopkjgf7oy90nm/qian/'
  },

})
